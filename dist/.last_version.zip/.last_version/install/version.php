<?
$arModuleVersion = array(
	"VERSION" => "2.2.2",
	"VERSION_DATE" => "2023-01-31 13:05:00"
);
?>