<?
$arModuleVersion = array(
	"VERSION" => "2.2.3",
	"VERSION_DATE" => "2023-02-02 13:05:00"
);
?>