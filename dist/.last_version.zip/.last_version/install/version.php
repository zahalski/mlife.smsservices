<?
$arModuleVersion = array(
	"VERSION" => "2.2.1",
	"VERSION_DATE" => "2022-01-15 19:58:00"
);
?>