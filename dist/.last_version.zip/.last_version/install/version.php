<?
$arModuleVersion = array(
	"VERSION" => "2.2.5",
	"VERSION_DATE" => "2024-09-15 08:28:00"
);
?>