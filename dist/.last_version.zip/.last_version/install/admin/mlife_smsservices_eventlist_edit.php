<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mlife.smsservices/admin/eventlist_edit.php");
?>